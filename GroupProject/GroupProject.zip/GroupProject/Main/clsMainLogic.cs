﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject.Main
{
    class clsMainLogic
    {
        /// <summary>
        /// Load Definitions
        /// </summary>
        internal static void LoadDefinitions()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save Definitions
        /// </summary>
        internal static void SaveDefinitions()
        {
            throw new NotImplementedException();
        }
    }
}
