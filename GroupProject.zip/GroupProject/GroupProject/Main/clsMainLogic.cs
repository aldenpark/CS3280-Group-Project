﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject
{
    class clsMainLogic
    {
        // What business logic is there?

        // example
        //public static List<Definitions> GetDefinitions()
        //{

        //    DataSet ds = new DataSet();
        //    int iRet = 0;
        //    List<Definitions> ObjectVar = new List<Definitions>();
        //    clsDataAccess clsData = new clsDataAccess();
        //    try
        //    {
        //        ds = clsData.ExecuteSQLStatement(clsMainSQL.SomeQuery, ref iRet);

        //        for (int i = 0; i < iRet; i++)
        //        {
        //            ObjectVar.Add(new Definitions()
        //            {
        //                Id = Int32.Parse(ds.Tables[0].Rows[i][0].ToString()),
        //                Name = ds.Tables[0].Rows[i][i].ToString().ToString()
        //            });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." + MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
        //    }

        //    return ObjectVar;
        //}
    }
}
