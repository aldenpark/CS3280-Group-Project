﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject.Main
{
    class clsMainSQL
    {
        // What do I need to query as part of the business logic?

        // example
        //internal static string someQuery
        //{
        //    get
        //    {
        //        return "Select field1, field2 from SOMETABLE";
        //    }
        //}

    }

}
